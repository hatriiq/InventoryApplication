﻿using System;
using System.Windows.Forms;

namespace WGUSOFTWARE1
{
    internal static class Program
    {

        //Main

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainScreen());
        }
    }
}