﻿using System.Diagnostics;
using System.IO.Ports;
using System.Xml.Linq;

namespace WGUSOFTWARE1
{
    public class OutsourcedPart : Parts
    {
        public string CompanyName { get; set; }
        public OutsourcedPart()
        {/*constructor*/}
        public OutsourcedPart(int partID, string name, int inStock, decimal price, int max, int min, string companyCompanyName)
        {
            PartID = partID;
            Name = name;
            InStock = inStock;
            Price = price.ToString();
            Max = max;
            Min = min;
            CompanyName = companyCompanyName;
        }
    }
}