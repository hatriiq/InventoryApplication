﻿namespace WGUSOFTWARE1
{
    public abstract class Parts
    {
        public int Max { get; set; }
        public int Min { get; set; }
        public int PartID { get; set; }
        public string Name { get; set; }
        public int InStock { get; set; }
        private decimal price;
        public string Price
        {
            get => price.ToString("C");
            set
            {
                if (!value.StartsWith("$"))
                {
                    price = decimal.Parse(value);
                }
                else
                {
                    price = decimal.Parse(value.Substring(1));
                }

            }
        }
    }
}