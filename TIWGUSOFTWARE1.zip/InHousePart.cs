﻿using System.Diagnostics;
using System.IO.Ports;
using System.Xml.Linq;

namespace WGUSOFTWARE1
{
    public class InHousePart : Parts
    {
        public int machineID;

        public int MachineID { get; set; }


        public InHousePart()
        {/* Constructor*/}

        public InHousePart(int partID, string name, int inStock, decimal price, int max, int min, int machineID)
        {
            PartID = partID;
            Name = name;
            InStock = inStock;
            Price = price.ToString();
            Max = max;
            Min = min;
            MachineID = machineID;
        }
    }
}