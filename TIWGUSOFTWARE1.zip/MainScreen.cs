﻿using System;
using System.Windows.Forms;

namespace WGUSOFTWARE1
{
    public partial class MainScreen : Form
    {
        public MainScreen()
        {
            InitializeComponent();
            MainScreenFormLoad();
        }

        public void MainScreenFormLoad()
        {
            Inventory.FakeProduct();

            var partsBindingSource = new BindingSource();
            partsBindingSource.DataSource = Inventory.Parts;
            mainScreenPartsGrid.DataSource = partsBindingSource;

            mainScreenPartsGrid.Columns["PartID"].HeaderText = "Part ID";
            mainScreenPartsGrid.Columns["Name"].HeaderText = "Part Name";
            mainScreenPartsGrid.Columns["InStock"].HeaderText = "Inventory";
            mainScreenPartsGrid.Columns["Price"].HeaderText = "Price";
            mainScreenPartsGrid.Columns["Max"].HeaderText = "Max";
            mainScreenPartsGrid.Columns["Min"].HeaderText = "Min";

            var productBindingSource = new BindingSource();
            productBindingSource.DataSource = Inventory.Products;
            mainScreenProductGrid.DataSource = productBindingSource;

            mainScreenProductGrid.Columns["ProductID"].HeaderText = "Product ID";
            mainScreenProductGrid.Columns["Name"].HeaderText = "Product Name";
            mainScreenProductGrid.Columns["InStock"].HeaderText = "Inventory";
            mainScreenProductGrid.Columns["Price"].HeaderText = "Price";
            mainScreenProductGrid.Columns["Max"].HeaderText = "Max";
            mainScreenProductGrid.Columns["Min"].HeaderText = "Min";
        }

        private void BtnAddPart_Click(object sender, EventArgs e)
        {
            new AddPartScreen().ShowDialog();
        }

        private void BtnModifyPart_Click(object sender, EventArgs e)
        {
            if (mainScreenPartsGrid.CurrentRow.DataBoundItem is InHousePart inPart)
            {
                new ModifyPartScreen(inPart).ShowDialog();
            }
            else if (mainScreenPartsGrid.CurrentRow.DataBoundItem is OutsourcedPart outPart)
            {
                new ModifyPartScreen(outPart).ShowDialog();
            }
        }
        private void BtnDeletePart_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in mainScreenPartsGrid.SelectedRows)
            {
                mainScreenPartsGrid.Rows.RemoveAt(row.Index);
            }
        }

        private void BtnAddProduct_Click(object sender, EventArgs e)
        {
            new AddProductScreen().ShowDialog();
        }

        private void BtnModifyProduct_Click(object sender, EventArgs e)
        {
            Product selectedProduct = (Product)mainScreenProductGrid.CurrentRow.DataBoundItem;
            new ModifyProductScreen(selectedProduct).ShowDialog();
        }
        private void BtnDeleteProduct_Click(object sender, EventArgs e)
        {
            Product prod = (Product)mainScreenProductGrid.CurrentRow.DataBoundItem;
            if (prod.AssociatedParts.Count > 0)
            {
                MessageBox.Show("Cannot delete product with parts associated.");
                return;
            }

            foreach (DataGridViewRow row in mainScreenProductGrid.SelectedRows)
            {
                mainScreenProductGrid.Rows.RemoveAt(row.Index);
            }
        }

        private void BtnPartsSearch_Click(object sender, EventArgs e)
        {
            if (searchBoxPartsText < 1)
                return;

            Parts match = Inventory.SearchPart(searchBoxPartsText);


            foreach (DataGridViewRow row in mainScreenPartsGrid.Rows)
            {
                Parts part = (Parts)row.DataBoundItem;

                if (part.PartID == match.PartID)
                {
                    row.Selected = true;
                    break;
                }
                else
                {
                    row.Selected = false;
                }
            }
        }

        private void BtnProductsSearch_Click(object sender, EventArgs e)
        {
            if (searchBoxProductsText < 1)
                return;

            Product match = Inventory.LookupProduct(searchBoxProductsText);

            foreach (DataGridViewRow row in mainScreenProductGrid.Rows)
            {
                Product prod = (Product)row.DataBoundItem;

                if (prod.ProductID == match.ProductID)
                {
                    row.Selected = true;
                    break;
                }
                else
                {
                    row.Selected = false;
                }
            }
        }
        private void BtnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MainScreen_Load(object sender, EventArgs e)
        {

        }

        private void SearchBoxProducts_TextChanged(object sender, EventArgs e)
        {

        }
    }
}